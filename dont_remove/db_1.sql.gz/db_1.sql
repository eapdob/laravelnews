-- Adminer 4.8.1 MySQL 8.1.0 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `abouts`;
CREATE TABLE `abouts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `abouts` (`id`, `content`, `language`, `created_at`, `updated_at`) VALUES
(1,	'<p>test23</p>',	'uk',	'2024-02-09 17:30:01',	'2024-02-28 17:52:07'),
(2,	'<p>test1</p>',	'en',	'2024-02-09 17:30:17',	'2024-02-09 17:30:17');

DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `image` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admins_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admins` (`id`, `image`, `name`, `email`, `email_verified_at`, `password`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1,	'/test',	'Admin User',	'admin@gmail.com',	NULL,	'$2y$10$tB.Vc/oXVKfN82Oz0cCPhu50.svs8J3nIhejVdKBp.xqiDs5tl8M.',	1,	'KoWaKntBOrOy7dsmE9PCEDUEtyz8yImFNubKBulWm66McDl4i85V3fREffkr',	'2023-12-29 17:36:30',	'2024-02-25 00:54:17'),
(6,	'',	'Editor',	'eapdob1@gmail.com',	NULL,	'$2y$10$KQLmaFLHhonytS3Ngmtv2.bx.9FHByBWQH6TADfpWFZMF6OW9pshK',	1,	NULL,	'2024-02-28 14:01:23',	'2024-02-28 14:01:23'),
(7,	'',	'content',	'eapdob2@gmail.com',	NULL,	'$2y$10$7IOZm43XoRYdn94/Jm5Pu.UQzB7hp8V3bq7UG3/KItzz6O2WvLSbK',	1,	NULL,	'2024-02-28 17:55:04',	'2024-02-28 17:55:04');

DROP TABLE IF EXISTS `ads`;
CREATE TABLE `ads` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `home_top_bar_ad` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `home_top_bar_ad_status` tinyint(1) NOT NULL,
  `home_middle_ad` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `home_middle_ad_status` tinyint(1) NOT NULL,
  `view_page_ad` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `view_page_ad_status` tinyint(1) NOT NULL,
  `news_page_ad` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `news_page_ad_status` tinyint(1) NOT NULL,
  `side_bar_ad` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `side_bar_ad_status` tinyint(1) NOT NULL,
  `home_top_bar_ad_url` text COLLATE utf8mb4_unicode_ci,
  `home_middle_ad_url` text COLLATE utf8mb4_unicode_ci,
  `view_page_ad_url` text COLLATE utf8mb4_unicode_ci,
  `news_page_ad_url` text COLLATE utf8mb4_unicode_ci,
  `side_bar_ad_url` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ads` (`id`, `home_top_bar_ad`, `home_top_bar_ad_status`, `home_middle_ad`, `home_middle_ad_status`, `view_page_ad`, `view_page_ad_status`, `news_page_ad`, `news_page_ad_status`, `side_bar_ad`, `side_bar_ad_status`, `home_top_bar_ad_url`, `home_middle_ad_url`, `view_page_ad_url`, `news_page_ad_url`, `side_bar_ad_url`, `created_at`, `updated_at`) VALUES
(1,	'test',	1,	'test',	1,	'test',	1,	'test',	1,	'test',	1,	'test',	'test',	'test',	'test',	'test',	'2024-01-10 22:56:46',	'2024-01-11 09:34:29');

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `language` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `show_at_nav` tinyint(1) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `categories` (`id`, `language`, `name`, `slug`, `show_at_nav`, `status`, `created_at`, `updated_at`) VALUES
(1,	'en',	'Sport',	'sport',	1,	1,	'2023-12-24 12:54:13',	'2023-12-24 12:54:13'),
(2,	'en',	'Politics',	'politics',	0,	1,	'2023-12-24 12:54:25',	'2023-12-24 12:54:25'),
(3,	'en',	'It',	'it',	1,	1,	'2023-12-24 12:54:50',	'2023-12-24 12:54:50'),
(4,	'uk',	'Спорт',	'sport',	1,	1,	'2023-12-24 12:55:00',	'2023-12-24 12:55:00'),
(5,	'uk',	'Політика',	'politika',	1,	1,	'2023-12-24 12:55:09',	'2023-12-24 12:55:09'),
(6,	'uk',	'Айті',	'aiti',	1,	1,	'2023-12-24 12:55:20',	'2023-12-24 12:55:20'),
(7,	'en',	'Music',	'music',	1,	1,	'2024-01-02 18:53:27',	'2024-01-02 18:53:27'),
(8,	'uk',	'Музика',	'muzika',	1,	1,	'2024-01-02 18:53:36',	'2024-01-02 18:53:36'),
(9,	'en',	'test2',	'test2',	0,	1,	'2024-02-28 17:49:43',	'2024-02-28 17:49:43');

DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `news_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `parent_id` bigint unsigned DEFAULT NULL,
  `comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `comments_news_id_foreign` (`news_id`),
  KEY `comments_user_id_foreign` (`user_id`),
  KEY `comments_parent_id_foreign` (`parent_id`),
  CONSTRAINT `comments_news_id_foreign` FOREIGN KEY (`news_id`) REFERENCES `news` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comments_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `contacts`;
CREATE TABLE `contacts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `contacts` (`id`, `address`, `phone`, `email`, `language`, `created_at`, `updated_at`) VALUES
(2,	'test222',	'0000000000',	'eapdob@gmail.com',	'en',	'2024-02-10 14:19:17',	'2024-02-28 17:52:16'),
(3,	'test34',	'0000000001',	'eapdob@gmail.com',	'uk',	'2024-02-10 14:19:36',	'2024-02-28 17:52:13');

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `footer_grid_ones`;
CREATE TABLE `footer_grid_ones` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `language` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `footer_grid_ones` (`id`, `language`, `name`, `url`, `status`, `created_at`, `updated_at`) VALUES
(1,	'en',	'testfootergrinoneen',	'testfootergrinoneen',	1,	'2024-01-15 11:52:57',	'2024-01-15 11:52:57'),
(2,	'uk',	'testfootergrinoneuk1',	'testfootergrinoneuk1',	1,	'2024-01-15 11:53:14',	'2024-01-15 12:33:45');

DROP TABLE IF EXISTS `footer_grid_threes`;
CREATE TABLE `footer_grid_threes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `language` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `footer_grid_threes` (`id`, `language`, `name`, `url`, `status`, `created_at`, `updated_at`) VALUES
(1,	'en',	'testfootergrinthreeen',	'testfootergrinthreeen',	1,	'2024-01-15 15:18:07',	'2024-01-15 15:18:07'),
(3,	'uk',	'testfootergrinthreeuk',	'testfootergrinthreeuk',	1,	'2024-01-15 15:18:45',	'2024-01-15 15:18:45');

DROP TABLE IF EXISTS `footer_grid_twos`;
CREATE TABLE `footer_grid_twos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `language` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `footer_grid_twos` (`id`, `language`, `name`, `url`, `status`, `created_at`, `updated_at`) VALUES
(1,	'en',	'testfootergrintwoen',	'testfootergrintwoen',	1,	'2024-01-15 14:34:46',	'2024-01-15 14:51:56'),
(2,	'uk',	'testfootergrintwouk',	'testfootergrintwouk',	1,	'2024-01-15 14:35:02',	'2024-01-15 14:52:07');

DROP TABLE IF EXISTS `footer_infos`;
CREATE TABLE `footer_infos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `logo` text COLLATE utf8mb4_unicode_ci,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `copyright` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `footer_infos` (`id`, `logo`, `description`, `copyright`, `language`, `created_at`, `updated_at`) VALUES
(1,	'uploads/dimNBSuYCtonRudRJlgfAxTRp6MrH6.jpeg',	'Illo earum incididun',	'In proident mollit',	'en',	'2024-01-14 14:13:29',	'2024-01-14 14:13:29');

DROP TABLE IF EXISTS `footer_titles`;
CREATE TABLE `footer_titles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `footer_titles` (`id`, `key`, `value`, `language`, `created_at`, `updated_at`) VALUES
(1,	'grid_one_title',	'footeronetitleen',	'en',	'2024-01-15 23:13:30',	'2024-01-15 23:13:30'),
(2,	'grid_one_title',	'footeronetitleukkk',	'uk',	'2024-01-15 23:13:40',	'2024-01-15 23:18:03'),
(3,	'grid_one_title',	'footeronetitlee',	'en',	'2024-01-15 23:14:42',	'2024-01-15 23:14:42'),
(4,	'grid_two_title',	'footertwotitleuk',	'uk',	'2024-01-15 23:49:08',	'2024-01-15 23:49:08'),
(5,	'grid_two_title',	'footertwotitleen',	'en',	'2024-01-15 23:49:13',	'2024-01-15 23:49:13'),
(6,	'grid_three_title',	'footerthreetitleuk',	'uk',	'2024-01-15 23:49:26',	'2024-01-15 23:49:26'),
(7,	'grid_three_title',	'footerthreetitleen',	'en',	'2024-01-15 23:49:32',	'2024-01-15 23:49:32');

DROP TABLE IF EXISTS `home_section_settings`;
CREATE TABLE `home_section_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `category_section_one` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_section_two` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_section_three` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_section_four` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `home_section_settings` (`id`, `category_section_one`, `category_section_two`, `category_section_three`, `category_section_four`, `language`, `created_at`, `updated_at`) VALUES
(1,	'7',	'3',	'2',	'1',	'en',	'2024-01-02 18:55:28',	'2024-01-02 22:21:28'),
(2,	'8',	'6',	'5',	'4',	'uk',	'2024-01-02 21:25:11',	'2024-01-02 21:25:11');

DROP TABLE IF EXISTS `languages`;
CREATE TABLE `languages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `lang` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `default` tinyint(1) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `languages` (`id`, `lang`, `name`, `slug`, `default`, `status`, `created_at`, `updated_at`) VALUES
(1,	'en',	'English',	'en',	1,	1,	'2023-12-29 17:36:30',	'2023-12-29 17:36:30'),
(2,	'uk',	'Ukrainian',	'uk',	0,	1,	'2023-12-29 17:37:02',	'2023-12-29 17:37:02');

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(23,	'2014_10_12_000000_create_users_table',	1),
(24,	'2014_10_12_100000_create_password_reset_tokens_table',	1),
(25,	'2019_08_19_000000_create_failed_jobs_table',	1),
(26,	'2019_12_14_000001_create_personal_access_tokens_table',	1),
(27,	'2023_08_26_163706_create_admins_table',	1),
(28,	'2023_09_11_212546_create_languages_table',	1),
(29,	'2023_09_22_121930_create_categories_table',	1),
(30,	'2023_09_23_152537_create_news_table',	1),
(31,	'2023_09_24_111042_create_tags_table',	1),
(32,	'2023_09_24_112803_create_news_tags_table',	1),
(33,	'2023_12_24_190340_create_comments_table',	1),
(35,	'2024_01_02_150701_create_home_section_settings_table',	2),
(36,	'2024_01_04_204017_create_social_counts_table',	3),
(39,	'2024_01_10_172031_create_ads_table',	4),
(40,	'2024_01_11_105503_create_subscribers_table',	5),
(43,	'2024_01_12_231252_create_social_links_table',	6),
(45,	'2024_01_14_122808_create_footer_infos_table',	7),
(46,	'2024_01_14_141849_create_footer_grid_ones_table',	8),
(47,	'2024_01_15_125626_create_footer_grid_twos_table',	9),
(48,	'2024_01_15_150137_create_footer_grid_threes_table',	10),
(49,	'2024_01_15_201736_create_footer_titles_table',	11),
(50,	'2024_01_16_095305_create_abouts_table',	12),
(51,	'2024_02_09_173237_create_contacts_table',	13),
(53,	'2024_02_10_160746_create_receive_mails_table',	14),
(55,	'2024_02_12_064246_create_settings_table',	15),
(56,	'2024_02_14_102851_create_permission_tables',	16),
(57,	'2024_02_28_125928_add_group_name_to_permissions_table',	17);

DROP TABLE IF EXISTS `model_has_permissions`;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `model_has_roles`;
CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(8,	'App\\Models\\Admin',	1),
(9,	'App\\Models\\Admin',	6),
(9,	'App\\Models\\Admin',	7);

DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `language` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` bigint unsigned NOT NULL,
  `author_id` bigint unsigned NOT NULL,
  `image` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_breaking_news` tinyint(1) NOT NULL DEFAULT '0',
  `show_at_slider` tinyint(1) NOT NULL DEFAULT '0',
  `show_at_popular` tinyint(1) NOT NULL DEFAULT '0',
  `is_approved` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `views` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `news_category_id_foreign` (`category_id`),
  KEY `news_author_id_foreign` (`author_id`),
  CONSTRAINT `news_author_id_foreign` FOREIGN KEY (`author_id`) REFERENCES `admins` (`id`),
  CONSTRAINT `news_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `news` (`id`, `language`, `category_id`, `author_id`, `image`, `title`, `slug`, `content`, `meta_title`, `meta_description`, `is_breaking_news`, `show_at_slider`, `show_at_popular`, `is_approved`, `status`, `views`, `created_at`, `updated_at`) VALUES
(1,	'en',	1,	1,	'uploads/YOdQ0EQuSHw1MBuwnXFZz8ZJss1h9u.jpeg',	'sport1',	'sport1',	'<p>sport1<br></p>',	'sport1',	'sport1',	1,	1,	1,	1,	1,	0,	'2023-12-24 12:57:02',	'2023-12-24 12:57:02'),
(2,	'en',	1,	1,	'uploads/kAxTsWLtSgliKyDxuEySkjHLTkj7rm.jpeg',	'sport2',	'sport2',	'<p>sport2<br></p>',	'sport2',	'sport2',	1,	1,	1,	1,	1,	1,	'2023-12-24 12:57:23',	'2024-01-12 16:54:02'),
(3,	'en',	1,	1,	'uploads/BRixsmPwT6A4uMzbZHEZOx8sXpNfnm.jpeg',	'sport3',	'sport3',	'<p>sport3<br></p>',	'sport3',	'sport3',	1,	1,	1,	1,	1,	0,	'2023-12-24 12:57:38',	'2023-12-24 12:57:38'),
(4,	'en',	2,	1,	'uploads/xQ736aMa2IP0Y0hQD3nER4wLKbn9Jl.jpeg',	'politics1',	'politics1',	'<p>politics1<br></p>',	'politics1',	'politics1',	1,	1,	1,	1,	1,	1,	'2023-12-24 12:57:55',	'2024-01-08 19:02:32'),
(5,	'en',	2,	1,	'uploads/5G17dzOxTTNgTePfBrBuBlSMEhhnHc.jpeg',	'politics2',	'politics2',	'<p>politics2<br></p>',	'politics2',	'politics2',	1,	1,	1,	1,	1,	0,	'2023-12-24 12:58:13',	'2023-12-24 12:58:13'),
(6,	'en',	2,	1,	'uploads/EaYy3PSNQYeoyDC1C8QWyzTrO2jQRr.jpeg',	'politics3',	'politics3',	'<p>politics3<br></p>',	'politics3',	'politics3',	1,	1,	1,	1,	1,	0,	'2023-12-24 12:58:30',	'2023-12-24 12:58:30'),
(7,	'en',	3,	1,	'uploads/19pc9XUt78gywwzdz26kWWTeUf6Law.jpeg',	'it1',	'it1',	'<p>it1<br></p>',	'it1',	'it1',	1,	1,	1,	1,	1,	5,	'2023-12-24 12:58:46',	'2024-02-23 14:45:14'),
(8,	'en',	3,	1,	'uploads/gNxvn6spnTJrM7VX0uzJCJ41AKshXB.jpeg',	'it2',	'it2',	'<p>it2<br></p>',	'it2',	'it2',	1,	1,	1,	1,	1,	1,	'2023-12-24 12:59:02',	'2023-12-30 12:21:10'),
(9,	'en',	3,	1,	'uploads/ILHacsamaOTsRV1tDdjSsSnuFVNlNr.jpeg',	'it3',	'it3',	'<p>it3<br></p>',	'it3',	'it3',	1,	1,	1,	1,	1,	2,	'2023-12-24 12:59:17',	'2024-01-12 16:57:42'),
(10,	'uk',	4,	1,	'uploads/ji2faeuJDUM3j6IeoWtKGpIXe1oMvW.jpeg',	'спорт1',	'sport1',	'<p>спорт<br></p>',	'спорт1',	'спорт1',	1,	1,	1,	1,	1,	0,	'2023-12-24 12:59:47',	'2023-12-24 13:00:39'),
(11,	'uk',	4,	1,	'uploads/spzKBg3k7cVUIEZeMpGGuIyri7KVms.jpeg',	'спорт2',	'sport2',	'<p>спорт2<br></p>',	'спорт2',	'спорт2',	1,	1,	1,	1,	1,	0,	'2023-12-24 13:00:12',	'2023-12-24 13:00:12'),
(12,	'uk',	4,	1,	'uploads/v2VhyqJsEY9lRCNlD4rU5ukjHNrRHm.jpeg',	'спорт3',	'sport3',	'<p>спорт3<br></p>',	'спорт3',	'спорт3',	1,	1,	1,	1,	1,	0,	'2023-12-24 13:01:15',	'2023-12-24 13:01:15'),
(13,	'uk',	5,	1,	'uploads/1PDvzXAq83EHoQcwqtJeqqseLXo58Z.jpeg',	'політика1',	'politika1',	'<p>політика1<br></p>',	'політика1',	'політика1',	1,	1,	1,	1,	1,	0,	'2023-12-24 13:01:47',	'2023-12-24 13:01:47'),
(14,	'uk',	5,	1,	'uploads/SIdbrHH4JDx4B6Yw0rcIDpWYzeM1A9.jpeg',	'політика2',	'politika2',	'<p>політика2<br></p>',	'політика2',	'політика2',	1,	1,	1,	1,	1,	0,	'2023-12-24 13:02:11',	'2023-12-24 13:02:11'),
(15,	'uk',	5,	1,	'uploads/iMOF7tI6ItfXnFGX2l39eIC0xxTwOh.jpeg',	'політика3',	'politika3',	'<p>політика3<br></p>',	'політика3',	'політика3',	1,	1,	1,	1,	1,	0,	'2023-12-24 13:02:36',	'2023-12-24 13:02:36'),
(16,	'uk',	6,	1,	'uploads/yBupxTYzr0Z4sHXjebtOaW3FnDwGgc.jpeg',	'айті1',	'aiti1',	'<p>айті1<br></p>',	'айті1',	'айті1',	1,	1,	1,	1,	1,	2,	'2023-12-24 13:03:02',	'2023-12-30 10:03:55'),
(17,	'uk',	6,	1,	'uploads/dkEPNjGlRT09LQXNT0Yaz8Dld9BQvn.jpeg',	'айті2',	'aiti2',	'<p>айті2<br></p>',	'айті2',	'айті2',	1,	1,	1,	1,	1,	0,	'2023-12-24 13:04:11',	'2023-12-24 13:04:11'),
(18,	'uk',	6,	1,	'uploads/lFBgyoGa3i6NRQdrmqqXZKbRilWGrd.jpeg',	'айті3',	'aiti3',	'<p>айті3<br></p>',	'айті3',	'айті3',	1,	1,	1,	1,	1,	0,	'2023-12-24 13:04:35',	'2023-12-24 13:04:35'),
(19,	'en',	7,	1,	'uploads/V2ejp5dQf5jiLnPo8scd97djlvkhW2.jpg',	'music',	'music',	'<p>music1<br></p>',	'music',	'music',	1,	1,	1,	0,	1,	0,	'2024-01-02 18:54:05',	'2024-02-28 17:51:01'),
(20,	'uk',	8,	1,	'uploads/zmx9rl1h27OCA7yrR3WUeCZcyAPQiP.jpg',	'музика',	'muzika',	'<p>музика<br></p>',	'музика',	'музика',	1,	1,	1,	1,	1,	0,	'2024-01-02 18:54:40',	'2024-01-02 18:54:40'),
(21,	'en',	3,	1,	'uploads/ottQCLEsFMi2d0MRrJGDP2FpnA0KLn.jpeg',	'it4',	'it4',	'<p>it4<br></p>',	'it4',	'it4',	1,	1,	1,	0,	1,	0,	'2024-02-21 21:13:43',	'2024-02-21 21:13:56'),
(22,	'en',	1,	1,	'uploads/ASVwR3HUdkmpvOmTIs0qxrTfVQ9pQu.jpeg',	'test12345',	'test12345',	'<p>test12345<br></p>',	'test12345',	NULL,	1,	1,	1,	1,	1,	0,	'2024-02-28 17:51:31',	'2024-02-28 17:51:31');

DROP TABLE IF EXISTS `news_tags`;
CREATE TABLE `news_tags` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `news_id` bigint unsigned NOT NULL,
  `tag_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `news_tags_news_id_foreign` (`news_id`),
  KEY `news_tags_tag_id_foreign` (`tag_id`),
  CONSTRAINT `news_tags_news_id_foreign` FOREIGN KEY (`news_id`) REFERENCES `news` (`id`) ON DELETE CASCADE,
  CONSTRAINT `news_tags_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `news_tags` (`id`, `news_id`, `tag_id`, `created_at`, `updated_at`) VALUES
(1,	1,	1,	NULL,	NULL),
(2,	2,	2,	NULL,	NULL),
(3,	3,	3,	NULL,	NULL),
(4,	4,	4,	NULL,	NULL),
(5,	5,	5,	NULL,	NULL),
(6,	6,	6,	NULL,	NULL),
(7,	7,	7,	NULL,	NULL),
(8,	8,	8,	NULL,	NULL),
(9,	9,	9,	NULL,	NULL),
(11,	11,	11,	NULL,	NULL),
(12,	10,	12,	NULL,	NULL),
(13,	12,	13,	NULL,	NULL),
(14,	13,	14,	NULL,	NULL),
(15,	14,	15,	NULL,	NULL),
(16,	15,	16,	NULL,	NULL),
(17,	16,	17,	NULL,	NULL),
(18,	17,	18,	NULL,	NULL),
(19,	18,	19,	NULL,	NULL),
(21,	20,	21,	NULL,	NULL),
(23,	21,	23,	NULL,	NULL),
(24,	19,	24,	NULL,	NULL),
(25,	22,	25,	NULL,	NULL);

DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `group_name`, `created_at`, `updated_at`) VALUES
(42,	'category index',	'admin',	'Category Permissions',	'2024-02-28 13:43:22',	'2024-02-28 13:43:22'),
(43,	'category create',	'admin',	'Category Permissions',	'2024-02-28 13:43:22',	'2024-02-28 13:43:22'),
(44,	'category update',	'admin',	'Category Permissions',	'2024-02-28 13:43:22',	'2024-02-28 13:43:22'),
(45,	'category delete',	'admin',	'Category Permissions',	'2024-02-28 13:43:22',	'2024-02-28 13:43:22'),
(46,	'news index',	'admin',	'News Permissions',	'2024-02-28 13:43:22',	'2024-02-28 13:43:22'),
(47,	'news create',	'admin',	'News Permissions',	'2024-02-28 13:43:23',	'2024-02-28 13:43:23'),
(48,	'news update',	'admin',	'News Permissions',	'2024-02-28 13:43:23',	'2024-02-28 13:43:23'),
(49,	'news delete',	'admin',	'News Permissions',	'2024-02-28 13:43:23',	'2024-02-28 13:43:23'),
(50,	'news status',	'admin',	'News Permissions',	'2024-02-28 13:43:23',	'2024-02-28 13:43:23'),
(51,	'news all-access',	'admin',	'News Permissions',	'2024-02-28 13:43:24',	'2024-02-28 13:43:24'),
(52,	'about index',	'admin',	'About Permissions',	'2024-02-28 13:43:24',	'2024-02-28 13:43:24'),
(53,	'about update',	'admin',	'About Permissions',	'2024-02-28 13:43:24',	'2024-02-28 13:43:24'),
(54,	'contact index',	'admin',	'Contact Permissions',	'2024-02-28 13:43:24',	'2024-02-28 13:43:24'),
(55,	'contact update',	'admin',	'Contact Permissions',	'2024-02-28 13:43:25',	'2024-02-28 13:43:25'),
(56,	'social count index',	'admin',	'Social Count Permissions',	'2024-02-28 13:43:25',	'2024-02-28 13:43:25'),
(57,	'social count create',	'admin',	'Social Count Permissions',	'2024-02-28 13:43:25',	'2024-02-28 13:43:25'),
(58,	'social count update',	'admin',	'Social Count Permissions',	'2024-02-28 13:43:25',	'2024-02-28 13:43:25'),
(59,	'social count delete',	'admin',	'Social Count Permissions',	'2024-02-28 13:43:26',	'2024-02-28 13:43:26'),
(60,	'contact message index',	'admin',	'Contact Message Permissions',	'2024-02-28 13:43:26',	'2024-02-28 13:43:26'),
(61,	'contact message delete',	'admin',	'Contact Message Permissions',	'2024-02-28 13:43:26',	'2024-02-28 13:43:26'),
(62,	'home section index',	'admin',	'Home Section Setting Permissions',	'2024-02-28 13:43:26',	'2024-02-28 13:43:26'),
(63,	'home section update',	'admin',	'Home Section Setting Permissions',	'2024-02-28 13:43:27',	'2024-02-28 13:43:27'),
(64,	'advertisement index',	'admin',	'Advertisement Permissions',	'2024-02-28 13:43:27',	'2024-02-28 13:43:27'),
(65,	'advertisement update',	'admin',	'Advertisement Permissions',	'2024-02-28 13:43:27',	'2024-02-28 13:43:27'),
(66,	'languages index',	'admin',	'Languages Permissions',	'2024-02-28 13:43:27',	'2024-02-28 13:43:27'),
(67,	'languages create',	'admin',	'Languages Permissions',	'2024-02-28 13:43:28',	'2024-02-28 13:43:28'),
(68,	'languages update',	'admin',	'Languages Permissions',	'2024-02-28 13:43:28',	'2024-02-28 13:43:28'),
(69,	'languages delete',	'admin',	'Languages Permissions',	'2024-02-28 13:43:28',	'2024-02-28 13:43:28'),
(70,	'subscribers index',	'admin',	'Subscribers Permissions',	'2024-02-28 13:43:28',	'2024-02-28 13:43:28'),
(71,	'subscribers delete',	'admin',	'Subscribers Permissions',	'2024-02-28 13:43:29',	'2024-02-28 13:43:29'),
(72,	'footer index',	'admin',	'Footer Permissions',	'2024-02-28 13:43:29',	'2024-02-28 13:43:29'),
(73,	'footer create',	'admin',	'Footer Permissions',	'2024-02-28 13:43:29',	'2024-02-28 13:43:29'),
(74,	'footer update',	'admin',	'Footer Permissions',	'2024-02-28 13:43:29',	'2024-02-28 13:43:29'),
(75,	'footer delete',	'admin',	'Footer Permissions',	'2024-02-28 13:43:30',	'2024-02-28 13:43:30'),
(76,	'access management index',	'admin',	'Access Management Permissions',	'2024-02-28 13:43:30',	'2024-02-28 13:43:30'),
(77,	'access management create',	'admin',	'Access Management Permissions',	'2024-02-28 13:43:30',	'2024-02-28 13:43:30'),
(78,	'access management update',	'admin',	'Access Management Permissions',	'2024-02-28 13:43:30',	'2024-02-28 13:43:30'),
(79,	'access management delete',	'admin',	'Access Management Permissions',	'2024-02-28 13:43:31',	'2024-02-28 13:43:31'),
(80,	'setting index',	'admin',	'Settings Permissions',	'2024-02-28 13:43:31',	'2024-02-28 13:43:31'),
(81,	'setting update',	'admin',	'Settings Permissions',	'2024-02-28 13:45:02',	'2024-02-28 13:45:02');

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `receive_mails`;
CREATE TABLE `receive_mails` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `seen` tinyint(1) NOT NULL DEFAULT '0',
  `replied` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `receive_mails` (`id`, `email`, `subject`, `message`, `seen`, `replied`, `created_at`, `updated_at`) VALUES
(1,	'eapdob@gmail.com',	'test',	'test',	1,	1,	'2024-02-11 22:23:05',	'2024-02-28 17:53:08');

DROP TABLE IF EXISTS `role_has_permissions`;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(46,	9),
(47,	9),
(48,	9),
(49,	9),
(42,	10),
(43,	10),
(44,	10),
(46,	10),
(47,	10),
(48,	10),
(50,	10),
(51,	10),
(52,	10),
(53,	10),
(57,	10),
(58,	10),
(62,	10),
(63,	10),
(64,	10),
(65,	10),
(66,	10),
(67,	10),
(68,	10),
(70,	10),
(72,	10),
(73,	10),
(74,	10);

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(8,	'Super Admin',	'admin',	'2024-02-21 10:45:57',	'2024-02-21 10:45:57'),
(9,	'editor',	'admin',	'2024-02-28 11:50:50',	'2024-02-28 11:50:50'),
(10,	'content',	'admin',	'2024-02-28 17:57:21',	'2024-02-28 17:57:21');

DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `settings` (`id`, `key`, `value`, `created_at`, `updated_at`) VALUES
(1,	'site_name',	'test123',	'2024-02-13 22:55:25',	'2024-02-13 22:57:00'),
(2,	'site_logo',	'uploads/C2HFm46XbQvpRxBCMPREDrmlyxGs6e.png',	'2024-02-13 22:57:00',	'2024-02-13 22:57:00'),
(3,	'site_favicon',	'uploads/RhkDcPQnJnPgLWLOuLN3dn8WDj3JvG.png',	'2024-02-13 22:57:00',	'2024-02-13 22:57:00'),
(4,	'site_seo_title',	'test title',	'2024-02-14 08:56:13',	'2024-02-14 08:56:13'),
(5,	'site_seo_description',	'test description',	'2024-02-14 08:56:13',	'2024-02-14 08:56:13'),
(6,	'site_seo_keywords',	'test keywords',	'2024-02-14 08:56:13',	'2024-02-14 08:56:13'),
(7,	'site_color',	'#c82424',	'2024-02-14 09:53:48',	'2024-02-14 09:53:48'),
(8,	'site_microsoft_api_host',	'microsoft-translator-text.p.rapidapi.com',	'2024-02-23 15:13:29',	'2024-02-23 15:13:29'),
(9,	'site_microsoft_api_key',	'9644c1868amsh7d7ad4b2feb85afp1973f8jsneb5a65f1a736',	'2024-02-23 15:13:29',	'2024-02-23 15:13:29');

DROP TABLE IF EXISTS `social_counts`;
CREATE TABLE `social_counts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `language` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fan_count` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fan_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `button_text` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `social_counts` (`id`, `language`, `icon`, `fan_count`, `fan_type`, `button_text`, `color`, `url`, `status`, `created_at`, `updated_at`) VALUES
(2,	'uk',	'fas fa-ad',	'10',	'liks',	'social-count-ad-uk',	'#2330a3',	'social-count-ad-uk',	1,	'2024-01-05 15:15:17',	'2024-01-05 15:15:31'),
(3,	'en',	'fas fa-address-book',	'10',	'liks',	'social-count-adress',	'#ed0f0f',	'social-count-adress',	0,	'2024-01-05 15:16:37',	'2024-02-28 17:52:38'),
(4,	'uk',	'fas fa-address-book',	'10',	'liks',	'social-count-adress-uk',	'#cc3b3b',	'social-count-adress-uk',	0,	'2024-01-05 15:17:05',	'2024-02-28 17:52:47');

DROP TABLE IF EXISTS `social_links`;
CREATE TABLE `social_links` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `social_links` (`id`, `icon`, `url`, `status`, `created_at`, `updated_at`) VALUES
(1,	'far fa-address-book',	'https://laravelnews.loc/test',	1,	'2024-01-12 23:22:25',	'2024-01-12 23:47:08'),
(4,	'fas fa-address-card',	'https://abs',	1,	'2024-02-28 17:53:41',	'2024-02-28 17:53:59');

DROP TABLE IF EXISTS `subscribers`;
CREATE TABLE `subscribers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `subscribers` (`id`, `email`, `created_at`, `updated_at`) VALUES
(2,	'dewavyhar@mailinator.com',	'2024-01-12 13:38:28',	'2024-01-12 13:38:28'),
(3,	'syjylaru@mailinator.com',	'2024-01-12 13:39:30',	'2024-01-12 13:39:30'),
(4,	'sucijutogi@mailinator.com',	'2024-01-12 16:55:02',	'2024-01-12 16:55:02'),
(5,	'buvaro@mailinator.com',	'2024-01-12 16:58:03',	'2024-01-12 16:58:03');

DROP TABLE IF EXISTS `tags`;
CREATE TABLE `tags` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tags` (`id`, `name`, `language`, `created_at`, `updated_at`) VALUES
(1,	'sport1',	'1',	'2023-12-24 12:57:02',	'2023-12-24 12:57:02'),
(2,	'sport2',	'1',	'2023-12-24 12:57:23',	'2023-12-24 12:57:23'),
(3,	'sport3',	'1',	'2023-12-24 12:57:38',	'2023-12-24 12:57:38'),
(4,	'politics1',	'1',	'2023-12-24 12:57:55',	'2023-12-24 12:57:55'),
(5,	'politics2',	'1',	'2023-12-24 12:58:13',	'2023-12-24 12:58:13'),
(6,	'politics3',	'1',	'2023-12-24 12:58:30',	'2023-12-24 12:58:30'),
(7,	'it1',	'1',	'2023-12-24 12:58:46',	'2023-12-24 12:58:46'),
(8,	'it2',	'1',	'2023-12-24 12:59:02',	'2023-12-24 12:59:02'),
(9,	'it3',	'1',	'2023-12-24 12:59:17',	'2023-12-24 12:59:17'),
(11,	'спорт2',	'2',	'2023-12-24 13:00:12',	'2023-12-24 13:00:12'),
(12,	'спорт1',	'2',	'2023-12-24 13:00:39',	'2023-12-24 13:00:39'),
(13,	'спорт3',	'2',	'2023-12-24 13:01:15',	'2023-12-24 13:01:15'),
(14,	'політика1',	'2',	'2023-12-24 13:01:47',	'2023-12-24 13:01:47'),
(15,	'політика2',	'2',	'2023-12-24 13:02:11',	'2023-12-24 13:02:11'),
(16,	'політика3',	'2',	'2023-12-24 13:02:36',	'2023-12-24 13:02:36'),
(17,	'айті1',	'2',	'2023-12-24 13:03:02',	'2023-12-24 13:03:02'),
(18,	'айті2',	'2',	'2023-12-24 13:04:11',	'2023-12-24 13:04:11'),
(19,	'айті3',	'2',	'2023-12-24 13:04:35',	'2023-12-24 13:04:35'),
(21,	'музика',	'uk',	'2024-01-02 18:54:40',	'2024-01-02 18:54:40'),
(23,	'it4',	'en',	'2024-02-21 21:13:56',	'2024-02-21 21:13:56'),
(24,	'music',	'en',	'2024-02-28 17:51:01',	'2024-02-28 17:51:01'),
(25,	'test12345',	'en',	'2024-02-28 17:51:31',	'2024-02-28 17:51:31');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- 2024-02-28 17:59:42
